from pathlib import Path

root_path = Path(__file__).parent
