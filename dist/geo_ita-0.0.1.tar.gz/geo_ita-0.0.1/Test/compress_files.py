from geo_ita.src._data import create_df

if __name__ == '__main__':
    create_df()

